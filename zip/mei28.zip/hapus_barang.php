<?php
include 'koneksi.php';

if (isset($_GET['id'])) {
    $id_barang = $_GET['id'];

    // Soft delete barang dengan mengatur kolom is_deleted menjadi 1
    $sql = "UPDATE barang SET is_deleted = 1 WHERE id_barang = '$id_barang'";
    if ($conn->query($sql) === TRUE) {
        // Redirect ke halaman daftar barang setelah soft delete berhasil
        header('Location: edit.php');
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    echo "ID barang tidak diset.";
}

$conn->close();
?>
